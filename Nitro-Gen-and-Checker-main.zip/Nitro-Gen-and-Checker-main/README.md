# Nitro Generator and Checker
Nitro Generator and Checker is a free software used to generate and check Discord Nitro Cods

## Liscence
Discord Nitro Generator and Checker © 2021 by Psycho649 is licensed under Attribution-NonCommercial-NoDerivatives 4.0 International.

To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-nd/4.0/

## Usage
Please Note that this is for educational purposes and **IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.**
## Installation
To get a local copy up and running follow these simple steps.

You need to install Python, that can be done  [here](https://www.python.org/)


 -  Clone the repo
    ```
    git clone https://github.com/Psycho649/Nitro-Gen-and-Checker.git
    ```
    

    
 -  Install Python packages
    
    ### Windows:
    ```
    py -3 -m pip install -r requirements.txt
    ```
    
    ### Unix:
    ```
    python3.8 -m pip install -r requirements.txt
    ```
    

    ### Or this can be done using android with unrooted Termux

    ```
    git clone https://github.com/Psycho649/Nitro-Gen-and-Checker
    pkg install python
    pip install -r requirements.txt
    cd Discord-Nitro-Generator-and-Checker
    python3 main.py
    ```
## How-To
Run the  `main.py`  file using  `py -3 main.py`  The code will show you two prompts:

1.  How many codes to generate
2.  If you want to use a discord webhook, if you dont know how to get a discord webhook url it is located at  
    `channel settings » intergrations » webhooks » create webhook`  
    If you dont want to use a webhook simply leave this blank

The code will start generating and checking after that step
